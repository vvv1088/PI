# MIS 前端完整代码包(v85.1,2026-09-29 打包)

## 为什么不是一个 HTML

v70 起 MIS 从单文件改为**文件夹部署**:`index.html` 只是骨架(挂载点+核心),
功能代码在 9 个外挂 JS 里,浏览器打开 index.html 时会按相对路径加载它们。
只拿 index.html = 9 个模块全部缺失,页面空壳。

## 内容清单

| 路径 | 是什么 |
|---|---|
| `PI/index.html` | 入口(**构建产物**,由 src/ 拼出,不要直接改它) |
| `PI/mis-meta-api.js` | 系统 2 接口层:mode(mock/live)/token/metaApi() 唯一数据入口 |
| `PI/mis-meta-admin-mock.js` | 系统 2 管理页 mock 数据 |
| `PI/mis-naming.js` | 广告命名引擎(7 段命名契约 v2:生成/解析/发号) |
| `PI/mis-baselines.js` | 品牌基线 |
| `PI/mis-performance.js` | Closed-Loop Report / Spending |
| `PI/mis-assets.js` | 资产健康/状态 |
| `PI/mis-resources.js` | Brands/BM/Pixel/账户/App/Token/共享 |
| `PI/mis-operations.js` | 轮转/SOP/Dashboard |
| `PI/mis-analytics.js` | Analytics 四页 |
| `PI/src/` | index.html 的源码五块 + 模板(改代码在这里改) |
| `PI/tools/build.js` | 构建:node tools/build.js → 重拼 index.html |
| `PI/tools/smoke-test.js` | 冒烟测试(Playwright,35 视图) |
| `PI/demo_src/ + demo.html` | 演示种子与演示版(离线可开,免登录) |
| `PI/CHANGELOG.md` | 完整版本历史(v85.1 最新) |

## 部署口径(cPanel)

上传 `PI/index.html` + 9 个 `mis-*.js` 到同一目录即可(src/tools 是开发用,不必上传)。
当前 mis-meta-api.js 为 mock 模式;切 live 改顶部三行(mode/baseUrl/token)。

## 快速预览

不想配环境就双击 `PI/demo.html`——内置演示数据,离线可看全部页面。
